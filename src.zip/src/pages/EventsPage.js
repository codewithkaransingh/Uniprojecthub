import React, { useState, useEffect } from 'react';
import './EventsPage.css';

const EventsPage = () => {
  // Sample event data
  const [events, ] = useState([]);    //setEvents

  // Fetch events from backend (to be implemented later)
  useEffect(() => {
    // Fetch events from backend API
    // Example:
    // fetchEvents()
    //   .then(eventsData => setEvents(eventsData))
    //   .catch(error => console.error('Error fetching events:', error));
  }, []);

  return (
    <div className="events">
      <h1>Upcoming Events</h1>
      {events.length === 0 ? (
        <p>No upcoming events found.</p>
      ) : (
        <ul className="event-list">
          {events.map(event => (
            <li key={event.id} className="event-item">
              <h2>{event.name}</h2>
              <p><strong>Date:</strong> {event.date}</p>
              <p><strong>Location:</strong> {event.location}</p>
              <p>{event.description}</p>
              {/* Add additional event details as needed */}
              <a href={event.registrationLink} className="btn btn-primary">Register</a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default EventsPage;
