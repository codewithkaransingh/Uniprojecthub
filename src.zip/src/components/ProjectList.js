import React, { useState } from 'react';
import ProjectCard from '../components/ProjectCard';
import './ProjectList.css';

const ProjectsPage = () => {
  const initialProjects = [
    // Projects data...
    {
      id: 1,
      title: 'Project 1',
      description: ' Description of Project 1.',
      owner: 'Harsh',
      tags: ['Web Development', 'React', 'JavaScript'],
      startDate: '2022-01-01',
      endDate: '2022-02-01',
      technologies: ['HTML', 'CSS', 'JavaScript'],
      thumbnail: 'https://via.placeholder.com/150', // Placeholder image URL
      views: 100, // Example number of views
      downloads: 50, // Example number of downloads
      likes: 20, // Example number of likes
    },
    {
        id: 2,
        title: 'Project 2',
        description: 'Description of Project 2.',
        owner: 'Jane Smith',
        tags: ['Mobile App Development', 'React Native', 'Firebase'],
        startDate: '2022-02-01',
        endDate: '2022-03-01',
        technologies: ['React Native', 'Firebase'],
        thumbnail: 'https://via.placeholder.com/150',
        views: Math.floor(Math.random() * 500) + 100,
        downloads: Math.floor(Math.random() * 100) + 50,
        likes: Math.floor(Math.random() * 50) + 20,
      },      
    {
        id: 3,
        title: 'Project 3',
        description: 'Description of Project 3.',
        owner: 'Jane Smith',
        tags: ['Mobile App Development', 'React Native', 'Firebase'],
        startDate: '2022-02-01',
        endDate: '2022-03-01',
        technologies: ['React Native', 'Firebase'],
        thumbnail: 'https://via.placeholder.com/150', // Placeholder image URL
        views: 200, 
        downloads: 70, 
        likes: 30, 
      },
      {
        id: 4,
        title: 'Project 4',
        description: 'Description of Project 4.',
        owner: 'Alice Johnson',
        tags: ['Data Science', 'Python', 'Machine Learning'],
        startDate: '2022-05-10',
        endDate: '2022-06-20',
        technologies: ['Python', 'Machine Learning'],
        thumbnail: 'https://via.placeholder.com/150',
        views: Math.floor(Math.random() * 500) + 100,
        downloads: Math.floor(Math.random() * 100) + 50,
        likes: Math.floor(Math.random() * 50) + 20,
      },
  ];

  const [projects] = useState(initialProjects);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterField, setFilterField] = useState('title');
  const [sortBy, setSortBy] = useState(null);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleFilterChange = (e) => {
    setFilterField(e.target.value);
  };

  const handleSortChange = (e) => {
    setSortBy(e.target.value);
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setFilterField('title');
    setSortBy(null);
  };

  const filteredProjects = projects.filter((project) => {
    const query = searchQuery.toLowerCase();
    const fieldValue = String(project[filterField]).toLowerCase();
    return fieldValue.includes(query);
  });

  const sortedProjects = sortBy
    ? [...filteredProjects].sort((a, b) => {
        const fieldA = String(a[filterField]).toLowerCase();
        const fieldB = String(b[filterField]).toLowerCase();
        if (sortBy === 'asc') {
          return fieldA.localeCompare(fieldB);
        } else if (sortBy === 'desc') {
          return fieldB.localeCompare(fieldA);
        } else {
          return 0; // No sorting
        }
      })
    : filteredProjects;

  const displayProjects = sortedProjects.length > 0 ? sortedProjects : null;

  return (
    <div className="container">
      <div className="sidebar">
        <div className="search-and-sort">
          <input
            type="text"
            value={searchQuery}
            onChange={handleSearchChange}
            placeholder="Search projects..."
          />
          <select id="filterBy" value={filterField} onChange={handleFilterChange}>
            <option value="title">Filter By</option>
            <option value="title">Title</option>
            <option value="description">Description</option>
            <option value="tags">Tags</option>
            <option value="technologies">Technologies</option>
          </select>
          <select value={sortBy} onChange={handleSortChange}>
            <option value="">Sort By</option>
            <option value="asc">A-Z</option>
            <option value="desc">Z-A</option>
          </select>
          <button onClick={handleClearFilters}>
            {searchQuery || sortBy ? 'Clear Filters' : 'Clear'}
          </button>
        </div>
      </div>
      <div className="projects-container">
        {/* Project cards */}
        {displayProjects ? (
          displayProjects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))
        ) : (
          <div className="no-result-found">
            <p>No results found. Try Again!!</p>
            {/* You can add more creative messages or suggestions here */}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectsPage;
