// src/components/TrendingProjects.js
import React from 'react';

const TrendingProjects = () => {
  return (
    <div className="trending-projects">
      <h2>Trending Projects</h2>
      {/* Display trending projects here */}
    </div>
  );
};

export default TrendingProjects;
