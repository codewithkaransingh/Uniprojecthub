// src/components/Categories.js
import React from 'react';

const Categories = () => {
  return (
    <div className="categories">
      <h2>Categories</h2>
      {/* Display categories or tags here */}
    </div>
  );
};

export default Categories;
