import React from 'react';
import { Link } from 'react-router-dom';
import { FaBell, FaQuestionCircle, FaEnvelope, FaSearch, FaTwitter, FaFacebook, FaInstagram } from 'react-icons/fa'; // Import icons
import logo from '../images/logo.jpg';
import { useAuth0 } from '@auth0/auth0-react';
import './Header.css';

const Header = () => {
  const { isAuthenticated, loginWithRedirect, logout, user } = useAuth0();

  return (
    <header className="header">
      <div className="logo">
        <Link to="/">
          <img src={logo} alt="Project Management App" />
          <span className="site-name">UniProjectHub</span> {/* Replace 'Your Website Name' with the actual name */}
        </Link>
      </div>
      <nav className="nav">
        <ul className="nav-list">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/projects">Projects</Link></li>
          <li><Link to="/forums">Forums</Link></li>
          <li><Link to="/events">Events</Link></li>
          <li><Link to="/resources">Resources</Link></li>
          {isAuthenticated && (
            <>
              <li><Link to="/messages"><FaEnvelope /></Link></li> {/* Added messaging link */}
              <li><Link to="/notifications"><FaBell /></Link></li>
              <li><Link to="/profile">Profile</Link></li>
            </>
          )}
          <li><Link to="/faq"><FaQuestionCircle /></Link></li>
          <li><Link to="/contact-us">Contact Us</Link></li> {/* Added Contact Us link */}
        </ul>
      </nav>
      <div className="search-bar">
        <input type="text" placeholder="Search..." />
        <FaSearch className="search-icon" />
      </div>
      <div className="login-status">
        {isAuthenticated ? (
          <div className="user-info">
            <img className="user-avatar" src={user.picture} alt={user.name} />
            <span className="user-name">{user.name}</span>
            {' '}
            <button onClick={() => logout()} className="btn btn-secondary">Logout</button>
          </div>
        ) : (
          <div>
            <button onClick={() => loginWithRedirect()} className="btn btn-primary">Login</button>
            <Link to="/signup"><button className="btn btn-secondary">Sign Up</button></Link>
          </div>
        )}
      </div>
      <div className="social-media-links">
        <a href="https://twitter.com"><FaTwitter /></a>
        <a href="https://facebook.com"><FaFacebook /></a>
        <a href="https://instagram.com"><FaInstagram /></a>
      </div>
    </header>
  );
};

export default Header;
